# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '7f79c03bcbb30dc89d3125d2c902560c5490287781d8575f2db66ed51e82a0bf0c47bb290c57ca058ec6750c3a801438448d41afae14be7bd1dc04a745981aff'